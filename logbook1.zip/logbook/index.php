<?php
header("Location: ".BASE_URL);
die();
?>